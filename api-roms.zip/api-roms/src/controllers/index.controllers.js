export const index = async (req, res ) => {
  res.send('Bienvenido a la api ')
}